package com.codingdojo.fruityloops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruityloopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
