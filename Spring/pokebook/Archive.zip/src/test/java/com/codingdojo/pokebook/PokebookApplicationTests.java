package com.codingdojo.pokebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokebookApplicationTests {

	@Test
	void contextLoads() {
	}

}
