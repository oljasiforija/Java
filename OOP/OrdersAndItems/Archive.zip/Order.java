    import java.util.ArrayList;
    public class Order {
    public String name;
    public double total;
    public boolean ready;
    public ArrayList<Item> items = new ArrayList<Item>();

    public void totalOrder(){
        for(Item item : this.items){
            this.total += item.price;
        }
    }
    public void updateOrderStatus(){
        this.ready = !this.ready;
    }
}