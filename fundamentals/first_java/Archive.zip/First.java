public class First {
    public static void main(String[] args){
        System.out.println("Olja");
        System.out.println("27");
        System.out.println("Siforija");
    }
}